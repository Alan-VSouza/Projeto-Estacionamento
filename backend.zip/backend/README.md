# demo-auth-app
Pre-configured secure Spring Boot application template using JWT.
