package br.ifsp.demo.dto;

public class VeiculoDTO {
}
