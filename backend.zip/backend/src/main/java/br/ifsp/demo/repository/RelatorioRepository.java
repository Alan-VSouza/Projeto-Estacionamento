package br.ifsp.demo.repository;

public interface RelatorioRepository {
}
