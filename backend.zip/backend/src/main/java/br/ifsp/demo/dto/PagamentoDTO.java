package br.ifsp.demo.dto;

public class PagamentoDTO {
}
