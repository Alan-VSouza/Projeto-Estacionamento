package br.ifsp.demo.security.user;

public enum Role {
    USER,
    ADMIN
}
