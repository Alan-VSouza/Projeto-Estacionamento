package br.ifsp.demo.model;

public class Relatorio {
}
