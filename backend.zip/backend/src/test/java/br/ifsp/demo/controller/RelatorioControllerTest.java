package br.ifsp.demo.controller;

class RelatorioControllerTest {
}