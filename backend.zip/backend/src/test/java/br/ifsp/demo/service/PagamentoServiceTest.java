package br.ifsp.demo.service;

import br.ifsp.demo.model.Pagamento;
import br.ifsp.demo.model.TempoPermanencia;
import br.ifsp.demo.model.Veiculo;
import br.ifsp.demo.repository.PagamentoRepository;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.junit.jupiter.api.Nested;


import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;
import static org.mockito.ArgumentMatchers.any;


@ExtendWith(MockitoExtension.class)
class PagamentoServiceTest {

    @Mock
    private PagamentoRepository pagamentoRepository;

    @Mock
    private VeiculoService veiculoService;

    @Mock
    TempoPermanencia tempoPermanencia;

    @InjectMocks
    private PagamentoService service;

    private Veiculo veiculo;
    private Pagamento pagamento;

    @BeforeEach
    void setUp () {
        veiculo = new Veiculo();
        veiculo.setId(1L);
        veiculo.setPlaca("BQF-2994");
        veiculo.setTipoVeiculo("carro");
        veiculo.setHoraEntrada(LocalDateTime.of(2025,4,30,10,0,0));
        veiculo.setModelo("Escort");
        veiculo.setCor("prata");

        pagamento = new Pagamento();
        pagamento.setUuid(UUID.randomUUID());
        pagamento.setVeiculo(veiculo);
        pagamento.setHoraEntrada(veiculo.getHoraEntrada());
        pagamento.setHoraSaida(LocalDateTime.now());
        pagamento.setValor(43);
    }


    @Nested
    @DisplayName("TDD Tests")
    class TddTests {
        @Test
        @Tag("TDD")
        @Tag("UnitTest")
        @DisplayName("Deve salvar o pagamento")
        void deveSalvarPagamento() {

            service.salvarPagamento(pagamento);

            verify(pagamentoRepository, times(1)).save(any(Pagamento.class));
            verify(veiculoService).deletarVeiculo(pagamento.getVeiculo().getId());
            verify(tempoPermanencia, times(1)).calcularValorDaPermanencia(anyInt());


        }

        @Test
        @Tag("TDD")
        @Tag("UnitTest")
        @DisplayName("Deve deletar o pagamento")
        void deveDeletarPagamento() {

            when(pagamentoRepository.findById(pagamento.getUuid()))
                    .thenReturn(Optional.of(pagamento));


            service.deletarPagamento(pagamento);

            verify(pagamentoRepository, times(1)).delete(pagamento);

        }

        @Test
        @Tag("TDD")
        @Tag("UnitTest")
        @DisplayName("Deve atualizar o pagamento")
        void deveAtualizarPagamento() {

            when(pagamentoRepository.findById(pagamento.getUuid())).thenReturn(Optional.of(pagamento));

            LocalDateTime novaEntrada = LocalDateTime.now().minusHours(3);
            LocalDateTime novaSaida = LocalDateTime.now().minusHours(1);
            double novoValor = 44;

            Pagamento pagamentoAtualizado = service.atualizarPagamento(pagamento.getUuid(), novaEntrada, novaSaida, veiculo, novoValor);

            assertThat(pagamentoAtualizado.getHoraEntrada()).isEqualTo(novaEntrada);
            assertThat(pagamentoAtualizado.getHoraSaida()).isEqualTo(novaSaida);
            assertThat(pagamentoAtualizado.getVeiculo()).isEqualTo(veiculo);
            assertThat(pagamentoAtualizado.getValor()).isEqualTo(44);

            verify(pagamentoRepository, times(1)).save(any(Pagamento.class));

        }

        @Test
        @Tag("TDD")
        @Tag("UnitTest")
        @DisplayName("Deve encontrar o pagamento pelo UUID")
        void deveEncontrarPagamentoPeloUuid() {
            UUID uuid = pagamento.getUuid();

            when(pagamentoRepository.findById(uuid)).thenReturn(Optional.of(pagamento));

            Pagamento result = service.buscarPorId(uuid);

            assertThat(result).isNotNull();
            assertThat(result.getUuid()).isEqualTo(uuid);
            verify(pagamentoRepository, times(2)).findById(uuid);
        }

        @Test
        @Tag("TDD")
        @Tag("UnitTest")
        @DisplayName("Testa salvar pagamento calculando o valor de permanencia")
        void testaSalvarPagamentoCalculandoOValorDePermanencia() {
            pagamento.setHoraSaida(LocalDateTime.of(2025,4,30,13,1,0));

            when(tempoPermanencia.calcularValorDaPermanencia(anyInt())).thenReturn(26.0);

            service.salvarPagamento(pagamento);

            assertEquals(26.0, pagamento.getValor());

            verify(pagamentoRepository, times(1)).save(pagamento);
            verify(veiculoService, times(1)).deletarVeiculo(pagamento.getVeiculo().getId());

        }

        @Test
        @Tag("TDD")
        @Tag("UnitTest")
        @DisplayName("Deve buscar pagamento por data")
        void deveBuscarPagamentoPorData() {
            LocalDate data = LocalDate.of(2025, 5, 2);

            pagamento.setHoraEntrada(data.atTime(9, 0));
            pagamento.setHoraSaida(data.atTime(10, 0));

            when(pagamentoRepository.findByHoraSaidaBetween(
                    data.atStartOfDay(),
                    data.atTime(23, 59, 59 ))
            ).thenReturn(List.of(pagamento));

            List<Pagamento> resultado = service.buscarPorData(data);

            assertThat(resultado).hasSize(1).containsExactly(pagamento);
        }

    }

    @Nested
    @DisplayName("Testando mensagens de erro")
    class TestandoMensagensDeErro {

        @ParameterizedTest
        @Tag("UnitTest")
        @CsvSource(
                value = {
                        "null, 2025-04-30T17:00:00, 20.0, Hora de entrada nao pode ser nula",
                        "2025-04-30T15:30:00, null, 20.0, Hora de saida nao pode ser nula",
                        "2025-04-30T15:30:00, 2025-04-30T17:00:00, -10.0, Valor nao pode ser menor que zero"
                },
                nullValues = "null"
        )
        void mensagensDeErroAoSalvarPagamento(String horaEntrada, String horaSaida, Double valor, String mensagem) {
            LocalDateTime entrada = horaEntrada == null ? null : LocalDateTime.parse(horaEntrada);
            LocalDateTime saida = horaSaida == null ? null : LocalDateTime.parse(horaSaida);

            pagamento.setHoraEntrada(entrada);
            pagamento.setHoraSaida(saida);
            pagamento.setValor(valor);

            IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> service.salvarPagamento(pagamento));
            assertEquals(mensagem, exception.getMessage());

            verify(pagamentoRepository, never()).save(any());
        }

        @Test
        @Tag("UnitTest")
        @DisplayName("mensagem de erro quando veiculo e nulo")
        void mensagemDeErroQuandoVeiculoNulo() {

            pagamento.setVeiculo(null);

            IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> service.salvarPagamento(pagamento));
            assertEquals("Veiculo nao pode ser nulo", exception.getMessage());
        }

        @Test
        @Tag("UnitTest")
        @DisplayName("mensgaem de erro ao tentar excluir pagamento nulo")
        void mensagemDeErroAoExcluirPagamentoNulo() {

            IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, ()-> service.deletarPagamento(null));
            assertEquals("Pagamento nao pode ser nulo", exception.getMessage());

        }

        @ParameterizedTest
        @Tag("UnitTest")
        @CsvSource(
                value = {
                        "null, 2025-04-30T15:30:00, 2025-04-30T17:00:00, 15.0, Uuid nao pode ser nulo",
                        "123e4567-e89b-12d3-a456-426614174000, null, 2025-04-30T17:00:00, 15.0, Entrada nao pode ser nulo",
                        "123e4567-e89b-12d3-a456-426614174000, 2025-04-30T17:00:00, null, 10.0, Saida nao pode ser nulo",
                        "123e4567-e89b-12d3-a456-426614174000, 2025-04-30T15:30:00, 2025-04-30T17:00:00, -10.0, Valor nao pode ser menor que zero"
                },
                nullValues = "null"
        )
        void mensagensDeErroAoAtualizarPagamento(String uuid, String horaEntrada, String horaSaida, double valor, String mensagem) {
            LocalDateTime entrada = horaEntrada == null ? null : LocalDateTime.parse(horaEntrada);
            LocalDateTime saida = horaSaida == null ? null : LocalDateTime.parse(horaSaida);
            UUID uuidPagamento = uuid == null ? null : UUID.fromString(uuid);

            IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> service.atualizarPagamento(
                    uuidPagamento, entrada, saida, veiculo, valor
            ));
            assertEquals(mensagem, exception.getMessage());

        }

        @Test
        @Tag("UnitTest")
        @DisplayName("mensagem de erro ao atualizar pagamento com veiculo nulo")
        void mensagemDeErroAoAtualizarPagamentoNulo() {

            IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, ()-> service.atualizarPagamento(
                    UUID.randomUUID(), LocalDateTime.now().minusHours(2), LocalDateTime.now(), null, 0
            ));
            assertEquals("Veiculo nao pode ser nulo", exception.getMessage());

        }

        @Test
        @Tag("UnitTest")
        @DisplayName("mensagem de erro ao atualizar pagamento com UUID inexistente")
        void mensagemDeErroAoAtualizarPagamentoInexistente() {
            UUID uuidInexistente = UUID.randomUUID();

            when(pagamentoRepository.findById(uuidInexistente)).thenReturn(Optional.empty());

            IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () ->
                    service.atualizarPagamento(
                            uuidInexistente,
                            LocalDateTime.now().minusHours(1),
                            LocalDateTime.now(),
                            veiculo,
                            10.0
                    )
            );

            assertEquals("Pagamento não encontrado", exception.getMessage());
            verify(pagamentoRepository).findById(uuidInexistente);
        }

        @ParameterizedTest
        @Tag("UnitTest")
        @CsvSource(
                value ={
                "null, Uuid nao pode ser nulo",
                "123e4567-e89b-12d3-a456-426614174000, Esse pagamento nao existe"
            },
                nullValues = "null"
        )
        @DisplayName("mensagem de erro se if for nulo ou inexistente")
        void mensagemDeErroAoBuscarPagamentoPorUuidNulo(String uuid, String mensagem) {

            UUID uuidPagamento = uuid == null ? null : UUID.fromString(uuid);

            IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> service.buscarPorId(uuidPagamento));
            assertEquals(mensagem, exception.getMessage());

        }



    }



}